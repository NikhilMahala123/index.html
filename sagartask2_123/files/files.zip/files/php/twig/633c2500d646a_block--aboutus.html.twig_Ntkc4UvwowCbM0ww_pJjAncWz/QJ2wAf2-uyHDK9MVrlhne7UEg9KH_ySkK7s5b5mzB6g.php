<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/my_theme/templates/block/block--aboutus.html.twig */
class __TwigTemplate_4cac61530e47942e7fe8448e2300b238 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 28
        echo " <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css'>     


<div class=\"aboutus wow fadeInUp\" data-wow-delay=\".6s\">

<div class=\"aboutustitle\">  ";
        // line 33
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "field_aboutustitle", [], "any", false, false, true, 33), 33, $this->source), "html", null, true);
        echo " </div>
<div class=\"aboutusline\">    
 </div>

<div class=\"aboutusbody\"> ";
        // line 37
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "body", [], "any", false, false, true, 37), 37, $this->source), "html", null, true);
        echo "  </div>

</div>

";
        // line 77
        echo " 
";
    }

    public function getTemplateName()
    {
        return "themes/my_theme/templates/block/block--aboutus.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 77,  53 => 37,  46 => 33,  39 => 28,);
    }

    public function getSourceContext()
    {
        return new Source("{#
/**
 * @file
 * Theme override to display a block.
 *
 * Available variables:
 * - plugin_id: The ID of the block implementation.
 * - label: The configured label of the block if visible.
 * - configuration: A list of the block's configuration values.
 *   - label: The configured label for the block.
 *   - label_display: The display settings for the label.
 *   - provider: The module or other provider that provided this block plugin.
 *   - Block plugin specific settings will also be stored here.
 * - content: The content of this block.
 * - attributes: array of HTML attributes populated by modules, intended to
 *   be added to the main container tag of this template.
 *   - id: A valid HTML ID and guaranteed unique.
 * - title_attributes: Same as attributes, except applied to the main title
 *   tag that appears in the template.
 * - title_prefix: Additional output populated by modules, intended to be
 *   displayed in front of the main title tag that appears in the template.
 * - title_suffix: Additional output populated by modules, intended to be
 *   displayed after the main title tag that appears in the template.
 *
 * @see template_preprocess_block()
 */
#}
 <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css'>     


<div class=\"aboutus wow fadeInUp\" data-wow-delay=\".6s\">

<div class=\"aboutustitle\">  {{ content.field_aboutustitle }} </div>
<div class=\"aboutusline\">    
 </div>

<div class=\"aboutusbody\"> {{ content.body }}  </div>

</div>

{# 
<div class=\"aboutus2\"> 

  <div>
    <div class=\"aboutus2left\">
      <div class=\"aboutus2leftimg\"> <img  src=\"https://bootstrapmade.com/demo/templates/Avilon/assets/img/about-img.jpg\"  >  </div>
    </div>
  </div>

  <div class=\"aboutus2rightmain\">
    <div class=\"aboutus2right\">
      <div class=\"aboutus2right1\" > <h1>Lorem ipsum dolor sit amet, consectetur adipiscing elite storium paralate </h1>  </div>
      <div class=\"aboutus2right2\" > <h3>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </h3>  </div>
       <divclass=\"aboutus2right3\" > <h4> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ullamco laboris nisi ut aliquip ex ea commodo consequat.
      </h4>  </div>
     
     <div class=\"aboutus2rightlist\">
       <ul>  
         <li>  <span id=\"boot-icon\" class=\"bi bi-check-circle\" style=\"font-size: 27px; opacity: 0.7; color: rgb(0, 0, 255); -webkit-text-stroke: 2.1px rgb(40, 240, 237);\"></span>
          Ullamco laboris nisi ut aliquip ex ea commodo consequat. </li>
         <li> <span id=\"boot-icon\" class=\"bi bi-check-circle\" style=\"font-size: 27px; opacity: 0.7; color: rgb(0, 0, 255); -webkit-text-stroke: 2.1px rgb(40, 240, 237);\"></span>
           Duis aute irure dolor in reprehenderit in voluptate velit.  </li>
         <li> <span id=\"boot-icon\" class=\"bi bi-check-circle\" style=\"font-size: 27px; opacity: 0.7; color: rgb(0, 0, 255); -webkit-text-stroke: 2.1px rgb(40, 240, 237);\"></span>
           Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.  </li>
       </ul>
     </div>
      
     <div class=\"aboutus2right4\">
           Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate 
           velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum Libero justo laoreet sit amet cursus sit amet dictum sit.
             Commodo sed egestas egestas fringilla phasellus faucibus scelerisque eleifend donec
     </div> 
    </div>
  </div> #}
 
{# </div> #}
", "themes/my_theme/templates/block/block--aboutus.html.twig", "/var/www/html/sagartask2/web/themes/my_theme/templates/block/block--aboutus.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array();
        static $filters = array("escape" => 33);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
